package com.example.josephandroidproject;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CreateAccountActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        EditText newUsernameInput = findViewById(R.id.newUsername);
        EditText newPasswordInput = findViewById(R.id.newPassword);
        Button saveAccountButton = findViewById(R.id.saveAccountButton);

        saveAccountButton.setOnClickListener(v -> {
            String username = newUsernameInput.getText().toString().trim();
            String password = newPasswordInput.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter a username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            SharedPreferences userPrefs = getSharedPreferences("User_" + username, MODE_PRIVATE);
            if (userPrefs.contains("password")) {
                Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
            } else {
                // Save credentials
                userPrefs.edit()
                        .putString("password", password)
                        .apply();

                // Initialize goal preferences
                SharedPreferences goalPrefs = getSharedPreferences("UserPrefs_" + username, MODE_PRIVATE);
                goalPrefs.edit()
                        .putBoolean("hasVisited", false)
                        .apply();

                Toast.makeText(this, "Account created!", Toast.LENGTH_SHORT).show();
                finish(); // Navigate back to login
            }
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish(); // closes the current activity
        return true;
    }

}