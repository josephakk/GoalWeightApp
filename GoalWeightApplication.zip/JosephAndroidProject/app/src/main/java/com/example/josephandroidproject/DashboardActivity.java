package com.example.josephandroidproject;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class DashboardActivity extends AppCompatActivity {
    private ArrayList<WeightEntry> weightEntries;
    private WeightAdapter adapter;
    private WeightDatabaseHelper dbHelper;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // Get current user and init database
        username = getSharedPreferences("AppPrefs", MODE_PRIVATE)
                .getString("currentUser", "default");
        dbHelper = new WeightDatabaseHelper(this);

        // Load goal weight
        TextView goalText = findViewById(R.id.goalText);
        SharedPreferences prefs = getSharedPreferences("UserPrefs_" + username, MODE_PRIVATE);
        String goalWeight = prefs.getString("goalWeight", "Not set");
        goalText.setText(goalWeight.equals("Not set") ? "No goal set yet" : "Goal: " + goalWeight + " lbs");

        // UI Elements
        RecyclerView dataGrid = findViewById(R.id.dataGrid);
        EditText weightInput = findViewById(R.id.weightInput);
        Button addButton = findViewById(R.id.addWeightButton);
        Button setGoalButton = findViewById(R.id.setGoalButton);
        Button smsSettingsButton = findViewById(R.id.openSmsSettingsButton);

        // Set up RecyclerView
        weightEntries = new ArrayList<>();
        adapter = new WeightAdapter(weightEntries, this::deleteEntry);
        dataGrid.setLayoutManager(new LinearLayoutManager(this));
        dataGrid.setAdapter(adapter);
        loadEntriesFromDatabase();

        addButton.setOnClickListener(v -> {
            String input = weightInput.getText().toString().trim();
            if (!input.isEmpty()) {
                String date = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault()).format(new Date());
                long id = addEntryToDatabase(username, date, input);
                if (id != -1) {
                    weightEntries.add(new WeightEntry(id, date, input));
                    adapter.notifyItemInserted(weightEntries.size() - 1);
                    weightInput.setText("");


                    SharedPreferences userPrefs = getSharedPreferences("UserPrefs_" + username, MODE_PRIVATE);
                    String savedGoal = userPrefs.getString("goalWeight", "");
                    boolean smsEnabled = userPrefs.getBoolean("smsEnabled", false);
                    boolean hasPermission = ContextCompat.checkSelfPermission(
                            this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;

                    if (savedGoal.equals(input) && smsEnabled && hasPermission) {
                        sendGoalReachedSms();
                    }

                } else {
                    Toast.makeText(this, "Failed to save entry", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Please enter a weight", Toast.LENGTH_SHORT).show();
            }
        });

        setGoalButton.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, GoalWeightActivity.class);
            startActivity(intent);
        });

        smsSettingsButton.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, SmsSettingsActivity.class);
            startActivity(intent);
        });
    }

    private void loadEntriesFromDatabase() {
        weightEntries.clear();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(
                "weight_entries",
                new String[]{"_id", "date", "weight"},
                "username = ?",
                new String[]{username},
                null, null, null
        );

        while (cursor.moveToNext()) {
            long id = cursor.getLong(0);
            String date = cursor.getString(1);
            String weight = cursor.getString(2);
            weightEntries.add(new WeightEntry(id, date, weight));
        }

        cursor.close();
        adapter.notifyDataSetChanged();
    }

    private long addEntryToDatabase(String username, String date, String weight) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("date", date);
        values.put("weight", weight);
        return db.insert("weight_entries", null, values);
    }

    private void deleteEntry(long id, int position) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        int deleted = db.delete("weight_entries", "_id = ?", new String[]{String.valueOf(id)});
        if (deleted > 0) {
            weightEntries.remove(position);
            adapter.notifyItemRemoved(position);
        } else {
            Toast.makeText(this, "Failed to delete entry", Toast.LENGTH_SHORT).show();
        }
    }

    private void sendGoalReachedSms() {
        String phoneNumber = "1234567890";
        String message = "Congrats! You've reached your goal weight!";

        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phoneNumber, null, message, null, null);
    }
}