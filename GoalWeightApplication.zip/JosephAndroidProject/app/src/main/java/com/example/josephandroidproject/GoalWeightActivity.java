package com.example.josephandroidproject;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class GoalWeightActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal_weight);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        EditText goalInput = findViewById(R.id.goalWeightInput);
        Button saveGoalButton = findViewById(R.id.saveGoalButton);

        String username = getSharedPreferences("AppPrefs", MODE_PRIVATE).getString("currentUser", "default");

        saveGoalButton.setOnClickListener(v -> {
            String goal = goalInput.getText().toString().trim();
            if (!goal.isEmpty()) {
                getSharedPreferences("UserPrefs_" + username, MODE_PRIVATE)
                        .edit()
                        .putString("goalWeight", goal)
                        .putBoolean("hasVisited", true)
                        .apply();

                Toast.makeText(this, "Goal weight saved!", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(this, DashboardActivity.class);
                intent.putExtra("username", username);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(this, "Please enter a goal weight", Toast.LENGTH_SHORT).show();
            }
        });
    }
    @Override
    public boolean onSupportNavigateUp() {
        finish(); // Closes this screen and returns to the previous one
        return true;
    }



}