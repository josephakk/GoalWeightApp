package com.example.josephandroidproject;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText usernameInput = findViewById(R.id.usernameInput);
        EditText passwordInput = findViewById(R.id.passwordInput);
        Button loginButton = findViewById(R.id.loginButton);
        Button createAccountButton = findViewById(R.id.createAccountButton);

        loginButton.setOnClickListener(v -> {
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            // Check login credentials
            SharedPreferences loginPrefs = getSharedPreferences("User_" + username, MODE_PRIVATE);
            String savedPassword = loginPrefs.getString("password", null);

            if (savedPassword != null && savedPassword.equals(password)) {
                Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();

                // Save current user
                getSharedPreferences("AppPrefs", MODE_PRIVATE)
                        .edit()
                        .putString("currentUser", username)
                        .apply();

                // Check if user has already visited (goal set)
                SharedPreferences userPrefs = getSharedPreferences("UserPrefs_" + username, MODE_PRIVATE);
                boolean hasVisited = userPrefs.getBoolean("hasVisited", false);

                Intent intent = new Intent(this,
                        hasVisited ? DashboardActivity.class : GoalWeightActivity.class);
                intent.putExtra("username", username);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
            }
        });

        createAccountButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CreateAccountActivity.class);
            startActivity(intent);
        });
    }
}