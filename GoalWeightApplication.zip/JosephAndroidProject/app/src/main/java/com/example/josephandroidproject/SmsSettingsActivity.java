package com.example.josephandroidproject;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsSettingsActivity extends AppCompatActivity {
    private static final int SMS_PERMISSION_REQUEST_CODE = 2001;
    private TextView smsStatus;
    private String username;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        smsStatus = findViewById(R.id.smsStatus);
        Button toggleButton = findViewById(R.id.toggleSmsButton);

        username = getSharedPreferences("AppPrefs", MODE_PRIVATE)
                .getString("currentUser", "default");
        prefs = getSharedPreferences("UserPrefs_" + username, MODE_PRIVATE);

        updateStatusLabel();

        toggleButton.setOnClickListener(v -> {
            boolean granted = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED;

            boolean currentlyEnabled = prefs.getBoolean("smsEnabled", false);

            if (!granted && !currentlyEnabled) {
                // First-time permission request
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_REQUEST_CODE);
            } else {
                // Toggle SMS alerts
                boolean newState = !currentlyEnabled;
                prefs.edit().putBoolean("smsEnabled", newState).apply();
                Toast.makeText(this,
                        newState ? "SMS alerts enabled" : "SMS alerts disabled",
                        Toast.LENGTH_SHORT).show();
                updateStatusLabel();
            }
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish(); // Closes this screen and returns to the previous one
        return true;
    }

    private void updateStatusLabel() {
        boolean granted = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
        boolean enabled = prefs.getBoolean("smsEnabled", false);

        if (granted && enabled) {
            smsStatus.setText("SMS alerts are enabled ✅");
        } else if (!granted) {
            smsStatus.setText("Permission not granted ❌");
        } else {
            smsStatus.setText("SMS alerts are disabled ❌");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            boolean granted = grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED;

            if (granted) {
                prefs.edit().putBoolean("smsEnabled", true).apply();
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                prefs.edit().putBoolean("smsEnabled", false).apply();
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
            updateStatusLabel();
        }
    }
}