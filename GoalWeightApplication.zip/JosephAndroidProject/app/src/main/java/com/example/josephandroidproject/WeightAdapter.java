package com.example.josephandroidproject;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder> {
    private final ArrayList<WeightEntry> weightEntries;
    private final OnDeleteClickListener deleteClickListener;

    public interface OnDeleteClickListener {
        void onDelete(long id, int position);
    }

    public WeightAdapter(ArrayList<WeightEntry> weightEntries, OnDeleteClickListener listener) {
        this.weightEntries = weightEntries;
        this.deleteClickListener = listener;
    }

    @NonNull
    @Override
    public WeightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.weight_row, parent, false);
        return new WeightViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightViewHolder holder, int position) {
        WeightEntry entry = weightEntries.get(position);
        holder.dateText.setText(entry.getDate());
        holder.weightText.setText(entry.getWeight());

        holder.deleteButton.setOnClickListener(v ->
                deleteClickListener.onDelete(entry.getId(), holder.getAdapterPosition())
        );
    }

    @Override
    public int getItemCount() {
        return weightEntries.size();
    }

    static class WeightViewHolder extends RecyclerView.ViewHolder {
        TextView dateText, weightText;
        Button deleteButton;

        public WeightViewHolder(@NonNull View itemView) {
            super(itemView);
            dateText = itemView.findViewById(R.id.dateCell);
            weightText = itemView.findViewById(R.id.weightCell);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }
}