package com.example.josephandroidproject;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class WeightDatabaseHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "weighttracker.db";
    public static final int DB_VERSION = 1;

    public WeightDatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE weight_entries (" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT, " +
                "date TEXT, " +
                "weight TEXT);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // for now, just drop and recreate
        db.execSQL("DROP TABLE IF EXISTS weight_entries");
        onCreate(db);
    }
}