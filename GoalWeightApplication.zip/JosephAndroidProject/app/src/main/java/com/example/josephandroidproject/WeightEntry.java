package com.example.josephandroidproject;

public class WeightEntry {
    private final long id;
    private final String date;
    private final String weight;

    public WeightEntry(long id, String date, String weight) {
        this.id = id;
        this.date = date;
        this.weight = weight;
    }

    public long getId() {
        return id;
    }

    public String getDate() {
        return date;
    }

    public String getWeight() {
        return weight;
    }
}